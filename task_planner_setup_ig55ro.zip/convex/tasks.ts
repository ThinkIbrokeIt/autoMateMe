import { v } from "convex/values";
import { action, internalMutation, mutation, query } from "./_generated/server";
import { internal } from "./_generated/api";
import { getAuthUserId } from "@convex-dev/auth/server";
import OpenAI from "openai";

const openai = new OpenAI({
  baseURL: process.env.CONVEX_OPENAI_BASE_URL,
  apiKey: process.env.CONVEX_OPENAI_API_KEY,
});

export const listTaskLists = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];
    return await ctx.db
      .query("taskLists")
      .filter((q) => q.eq(q.field("userId"), userId))
      .collect();
  },
});

export const createTaskList = mutation({
  args: {
    name: v.string(),
    description: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    return await ctx.db.insert("taskLists", {
      ...args,
      userId,
    });
  },
});

export const getTasks = query({
  args: {
    listId: v.id("taskLists"),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("tasks")
      .withIndex("by_list", (q) => q.eq("listId", args.listId))
      .collect();
  },
});

export const updateTaskStatus = mutation({
  args: {
    taskId: v.id("tasks"),
    status: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.taskId, { status: args.status });
  },
});

export const planTasks = action({
  args: {
    listId: v.id("taskLists"),
    goal: v.string(),
    screenState: v.string(),
  },
  handler: async (ctx, args) => {
    // First plan the tasks using GPT
    const completion = await openai.chat.completions.create({
      model: "gpt-4.1-nano",
      messages: [
        {
          role: "system",
          content: `You are a task planning expert. Given a goal and screen state, break it down into executable steps.
          Format your response as JSON with this structure:
          {
            "reasoning": "Why you planned these tasks",
            "tasks": [
              {
                "description": "Task description",
                "reasoning": "Why this task is needed"
              }
            ]
          }`,
        },
        {
          role: "user",
          content: `Goal: ${args.goal}\nScreen state: ${args.screenState}`,
        },
      ],
    });

    const response = completion.choices[0].message.content;
    if (!response) throw new Error("No response from GPT");

    const plan = JSON.parse(response);

    // Save the tasks
    for (const task of plan.tasks) {
      await ctx.runMutation(internal.tasks.createTask, {
        listId: args.listId,
        description: task.description,
        reasoning: task.reasoning,
        screenState: args.screenState,
      });
    }
  },
});

export const createTask = internalMutation({
  args: {
    listId: v.id("taskLists"),
    description: v.string(),
    reasoning: v.string(),
    screenState: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("tasks", {
      ...args,
      status: "⬜",
    });
  },
});
