import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

export default defineSchema({
  ...authTables,
  taskLists: defineTable({
    name: v.string(),
    description: v.string(),
    userId: v.id("users"),
  }),
  tasks: defineTable({
    listId: v.id("taskLists"),
    description: v.string(),
    reasoning: v.string(),
    status: v.string(),
    coordinates: v.optional(v.array(v.number())),
    elementId: v.optional(v.string()),
    screenState: v.optional(v.string()),
  }).index("by_list", ["listId"]),
  screenCaptures: defineTable({
    taskId: v.id("tasks"),
    base64Image: v.string(),
    parsedElements: v.array(
      v.object({
        elementId: v.string(),
        coordinates: v.array(v.number()),
        type: v.string(),
      })
    ),
  }).index("by_task", ["taskId"]),
});
