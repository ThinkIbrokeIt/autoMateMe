import { Authenticated, Unauthenticated, useQuery, useMutation, useAction } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "./components/ui/toaster";
import { useState } from "react";
import { Id } from "../convex/_generated/dataModel";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm p-4 flex justify-between items-center border-b">
        <h2 className="text-xl font-semibold accent-text">autoMate Task Planner</h2>
        <SignOutButton />
      </header>
      <main className="flex-1 p-8">
        <div className="max-w-4xl mx-auto">
          <Content />
        </div>
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const taskLists = useQuery(api.tasks.listTaskLists);
  const createTaskList = useMutation(api.tasks.createTaskList);
  const [selectedList, setSelectedList] = useState<Id<"taskLists"> | null>(null);
  const [goal, setGoal] = useState("");
  const [screenState, setScreenState] = useState("");
  const planTasks = useAction(api.tasks.planTasks);
  const tasks = useQuery(api.tasks.getTasks, selectedList ? { listId: selectedList } : "skip");
  const updateTaskStatus = useMutation(api.tasks.updateTaskStatus);

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-8">
      <div className="text-center">
        <h1 className="text-5xl font-bold accent-text mb-4">autoMate Task Planner</h1>
        <Authenticated>
          <p className="text-xl text-slate-600">Welcome back, {loggedInUser?.email ?? "friend"}!</p>
        </Authenticated>
        <Unauthenticated>
          <p className="text-xl text-slate-600">Sign in to get started</p>
        </Unauthenticated>
      </div>

      <Unauthenticated>
        <SignInForm />
      </Unauthenticated>

      <Authenticated>
        <div className="space-y-8">
          <div className="space-y-4">
            <h2 className="text-2xl font-bold">Task Lists</h2>
            <div className="flex gap-4">
              <input
                type="text"
                placeholder="New list name"
                className="flex-1 px-4 py-2 border rounded"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && e.currentTarget.value) {
                    createTaskList({
                      name: e.currentTarget.value,
                      description: "Created from input",
                    });
                    e.currentTarget.value = "";
                  }
                }}
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {taskLists?.map((list) => (
                <div
                  key={list._id}
                  className={`p-4 border rounded cursor-pointer ${
                    selectedList === list._id ? "border-indigo-500 bg-indigo-50" : ""
                  }`}
                  onClick={() => setSelectedList(list._id)}
                >
                  <h3 className="font-semibold">{list.name}</h3>
                  <p className="text-sm text-slate-600">{list.description}</p>
                </div>
              ))}
            </div>
          </div>

          {selectedList && (
            <div className="space-y-4">
              <h2 className="text-2xl font-bold">Plan Tasks</h2>
              <div className="space-y-4">
                <textarea
                  placeholder="Enter your goal..."
                  className="w-full px-4 py-2 border rounded"
                  value={goal}
                  onChange={(e) => setGoal(e.target.value)}
                />
                <textarea
                  placeholder="Describe the current screen state..."
                  className="w-full px-4 py-2 border rounded"
                  value={screenState}
                  onChange={(e) => setScreenState(e.target.value)}
                />
                <button
                  className="px-4 py-2 bg-indigo-500 text-white rounded hover:bg-indigo-600"
                  onClick={() => {
                    if (goal && screenState) {
                      planTasks({
                        listId: selectedList,
                        goal,
                        screenState,
                      });
                    }
                  }}
                >
                  Plan Tasks
                </button>
              </div>

              <div className="space-y-4">
                <h3 className="text-xl font-semibold">Tasks</h3>
                {tasks?.map((task) => (
                  <div key={task._id} className="p-4 border rounded">
                    <div className="flex items-center gap-2">
                      <button
                        className="text-2xl"
                        onClick={() => {
                          updateTaskStatus({
                            taskId: task._id,
                            status: task.status === "⬜" ? "✅" : "⬜",
                          });
                        }}
                      >
                        {task.status}
                      </button>
                      <p>{task.description}</p>
                    </div>
                    <p className="text-sm text-slate-600 mt-2">{task.reasoning}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </Authenticated>
    </div>
  );
}
