import { v } from "convex/values";
import { action, internalAction } from "./_generated/server";
import { internal } from "./_generated/api";
import { ComputerTool, ToolCollection, ToolResult } from "./tools";

// Initialize tool collection
const toolCollection = new ToolCollection([new ComputerTool()]);

export const executeTools = internalAction({
  args: {
    tools: v.array(v.object({
      name: v.string(),
      input: v.any(),
    }))
  },
  handler: async (ctx, args) => {
    const results: ToolResult[] = [];
    
    for (const tool of args.tools) {
      const result = await toolCollection.run(tool.name, tool.input);
      results.push(result);
    }
    
    return results;
  }
});

export const executeTaskAction = action({
  args: {
    taskId: v.id("tasks"),
    toolCalls: v.array(v.object({
      name: v.string(),
      input: v.any(),
    }))
  },
  handler: async (ctx, args) => {
    // Execute the tools
    const results = await ctx.runAction(internal.executor.executeTools, {
      tools: args.toolCalls
    });
    
    // Update task status based on execution results
    const hasErrors = results.some(r => r.error !== undefined);
    await ctx.runMutation(internal.tasks.updateTaskStatus, {
      taskId: args.taskId,
      status: hasErrors ? "⬜" : "✅"
    });
    
    return results;
  }
});
