import { ToolError } from "./tools";

// Constants
const OUTPUT_DIR = "./tmp/outputs";

interface ScreenRegion {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
}

/**
 * Captures a screenshot of the current screen state.
 * In the browser environment, this is simulated since we can't access the actual screen.
 */
export async function getScreenshot(
  screenRegion?: ScreenRegion,
  isCursor: boolean = true
): Promise<{ screenshot: ImageData; path: string }> {
  try {
    // Create a unique ID for the screenshot
    const uuid = crypto.randomUUID();
    const path = `${OUTPUT_DIR}/screenshot_${uuid}.png`;

    // In browser we can't actually capture the screen
    // Instead we'll create a canvas to simulate the screen
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      throw new ToolError("Failed to get canvas context");
    }

    // Set canvas size to window dimensions
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    // Fill with a placeholder color
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // If screen region is provided, create a mask
    if (screenRegion) {
      const { x1, y1, x2, y2 } = screenRegion;
      
      // Create black mask
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      // Clear the specified region
      ctx.clearRect(x1, y1, x2 - x1, y2 - y1);
      
      // Draw content in the region
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(x1, y1, x2 - x1, y2 - y1);
    }

    // If cursor should be shown, draw a cursor
    if (isCursor) {
      // Get current mouse position
      const mouseX = 0; // In browser we don't have real cursor position
      const mouseY = 0;
      
      // Draw cursor
      ctx.beginPath();
      ctx.moveTo(mouseX, mouseY);
      ctx.lineTo(mouseX + 10, mouseY + 10);
      ctx.lineTo(mouseX + 5, mouseY + 10);
      ctx.lineTo(mouseX + 7, mouseY + 15);
      ctx.lineTo(mouseX + 4, mouseY + 14);
      ctx.lineTo(mouseX + 3, mouseY + 19);
      ctx.lineTo(mouseX + 2, mouseY + 14);
      ctx.lineTo(mouseX - 1, mouseY + 13);
      ctx.lineTo(mouseX + 1, mouseY + 10);
      ctx.lineTo(mouseX - 4, mouseY + 8);
      ctx.closePath();
      
      // Fill cursor
      ctx.fillStyle = '#000000';
      ctx.fill();
    }

    // Get the image data
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

    return {
      screenshot: imageData,
      path
    };
  } catch (error) {
    throw new ToolError(`Failed to capture screenshot: ${error}`);
  }
}
