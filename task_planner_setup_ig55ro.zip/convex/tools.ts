// Tool result type definitions
interface ToolResult {
  output?: string;
  error?: string;
  base64Image?: string;
  system?: string;
}

// Tool error class
class ToolError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ToolError";
  }
}

// Tool failure class
class ToolFailure implements ToolResult {
  error: string;
  
  constructor(error: string) {
    this.error = error;
  }
}

// Action type definition
type Action = 
  | "key"
  | "type"
  | "mouse_move"
  | "left_click"
  | "left_click_drag"
  | "right_click"
  | "middle_click"
  | "double_click"
  | "cursor_position"
  | "hover"
  | "wait"
  | "scroll_up"
  | "scroll_down"
  | "None";

interface Resolution {
  width: number;
  height: number;
}

interface ComputerToolOptions {
  display_height_px: number;
  display_width_px: number;
  display_number: number | null;
}

// Base tool interface matching BaseAnthropicTool
interface BaseTool {
  toParams(): {
    name: string;
    type: string;
    display_width_px?: number;
    display_height_px?: number;
    display_number?: number | null;
  };
  execute(input: Record<string, any>): Promise<ToolResult>;
}

// Computer tool implementation
class ComputerTool implements BaseTool {
  private readonly name = "computer";
  private readonly api_type = "computer_20241022";
  private width: number;
  private height: number;
  private display_num: number | null;
  private readonly screenshot_delay = 2.0;
  private readonly key_conversion: Record<string, string> = {
    "Page_Down": "pagedown",
    "Page_Up": "pageup",
    "Super_L": "win",
    "Escape": "esc"
  };

  constructor() {
    // In browser we'll use window dimensions
    this.width = window.innerWidth;
    this.height = window.innerHeight;
    this.display_num = null;
  }

  get options(): ComputerToolOptions {
    return {
      display_width_px: this.width,
      display_height_px: this.height,
      display_number: this.display_num,
    };
  }

  toParams() {
    return {
      name: this.name,
      type: this.api_type,
      ...this.options
    };
  }

  async execute(input: Record<string, any>): Promise<ToolResult> {
    const { action, text, coordinate } = input;

    try {
      // Mouse movement actions
      if (action === "mouse_move" || action === "left_click_drag") {
        if (!coordinate) {
          throw new ToolError(`coordinate is required for ${action}`);
        }
        if (text) {
          throw new ToolError(`text is not accepted for ${action}`);
        }
        if (!Array.isArray(coordinate) || coordinate.length !== 2) {
          throw new ToolError(`${coordinate} must be a tuple of length 2`);
        }
        if (!coordinate.every(i => typeof i === "number")) {
          throw new ToolError(`${coordinate} must be a tuple of numbers`);
        }

        const [x, y] = coordinate;
        if (action === "mouse_move") {
          return { output: `Moved mouse to (${x}, ${y})` };
        } else {
          return { output: `Dragged mouse to (${x}, ${y})` };
        }
      }

      // Keyboard actions
      if (action === "key" || action === "type") {
        if (!text) {
          throw new ToolError(`text is required for ${action}`);
        }
        if (coordinate) {
          throw new ToolError(`coordinate is not accepted for ${action}`);
        }
        if (typeof text !== "string") {
          throw new ToolError(`${text} must be a string`);
        }

        if (action === "key") {
          const keys = text.split('+').map(k => {
            const key = k.trim();
            return this.key_conversion[key] || key.toLowerCase();
          });
          return { output: `Pressed keys: ${keys.join('+')}` };
        } else {
          return { output: text };
        }
      }

      // Click actions
      if (["left_click", "right_click", "double_click", "middle_click", "cursor_position", "left_press"].includes(action)) {
        if (text) {
          throw new ToolError(`text is not accepted for ${action}`);
        }
        if (coordinate) {
          throw new ToolError(`coordinate is not accepted for ${action}`);
        }

        if (action === "cursor_position") {
          return { output: "X=0,Y=0" }; // Simulated position
        }
        return { output: `Performed ${action}` };
      }

      // Scroll actions
      if (action === "scroll_up" || action === "scroll_down") {
        return { output: `Performed ${action}` };
      }

      // Other actions
      if (action === "hover" || action === "wait") {
        return { output: `Performed ${action}` };
      }

      throw new ToolError(`Invalid action: ${action}`);
    } catch (error) {
      if (error instanceof ToolError) {
        return new ToolFailure(error.message);
      }
      return new ToolFailure(`Error executing computer tool: ${error}`);
    }
  }
}

// Tool collection class
class ToolCollection {
  private tools: BaseTool[];
  private toolMap: Map<string, BaseTool>;

  constructor(...tools: BaseTool[]) {
    this.tools = tools;
    this.toolMap = new Map(
      tools.map(tool => [tool.toParams().name, tool])
    );
  }

  toParams() {
    return this.tools.map(tool => tool.toParams());
  }

  async run(name: string, toolInput: Record<string, any>): Promise<ToolResult> {
    const tool = this.toolMap.get(name);
    if (!tool) {
      return new ToolFailure(`Tool ${name} is invalid`);
    }
    try {
      return await tool.execute(toolInput);
    } catch (error) {
      if (error instanceof ToolError) {
        return new ToolFailure(error.message);
      }
      return new ToolFailure(`Unexpected error: ${error}`);
    }
  }
}

export {
  ToolResult,
  ToolError,
  ToolFailure,
  BaseTool,
  ComputerTool,
  ToolCollection,
  type Action,
  type Resolution,
  type ComputerToolOptions,
};
